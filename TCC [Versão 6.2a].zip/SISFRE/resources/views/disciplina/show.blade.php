@extends('layout.base')

@section('titulo','Controle de Disciplinas')

@section('scripts')
    @include('scripts.modal')
@endsection

@section('conteudo')
        <div class="row container-fluid">
            <div class="col-md-12 col-md-offset-0">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row col-md-12 col-md-offset-0">
                            
                            @include('layout.flash')

                            @if($disciplinas->count() == 0 && empty($pesquisa))
                                
                                <div class="alert alert-danger btn-lg col-md-8 col-md-offset-2 text-center">
                                    Você não possui nenhuma disciplina cadastrada.
                                </div>

                                <div class="row col-md-2 col-md-offset-5">
                                    <div class="form-group text-center text-uppercase">
                                        <a href="{{route('disciplina.create')}}" class="btn btn-block btn-lg btn-primary">
                                            <span class="glyphicon glyphicon-plus"></span> Disciplina
                                        </a>   
                                    </div>
                                </div>
                            @elseif($disciplinas->count() == 0 && !empty($pesquisa) )
                                <div class="alert alert-info btn-lg col-md-8 col-md-offset-2 text-center">
                                    Nenhuma disciplina foi encontrada para a Pesquisa: <b class="text-uppercase"> {{$pesquisa}}</b>.
                                </div>

                                <div class="row col-md-2 col-md-offset-5">
                                    <div class="form-group text-center text-uppercase">
                                        <a href="{{route('disciplina.show')}}" class="btn btn-block btn-lg btn-primary">
                                            <span class="glyphicon glyphicon-arrow-left"></span> Voltar
                                        </a>   
                                    </div>
                                </div>
                            @else

                            <div class="row col-md-8 col-md-offset-0">
                                  <form method="GET" action="{{route('disciplina.show')}}">
                                    <div class="form-group col-md-8">
                                        <div class="input-group">
                                            <input type="text" class="form-control input-lg text-uppercase" name="pesquisa" value="{{old('pesquisa','')}}" id="pesquisa" placeholder="Pesquise pelo nome da disciplina" />
                                            <div class="input-group-btn">
                                                <button class="btn btn-primary"><span class="glyphicon glyphicon-search"></span></button>
                                            </div>

                                        </div>
                                    </div>   
                                  </form>
                             </div>

                            <div class="table-responsive col-md-12">
                                <div class="row col-md-12 col-md-offset-0">
                                    <div class="form-group pull-right">
                                        <a href="{{route('disciplina.create')}}" class="btn btn-primary text-uppercase" >
                                            <span class="glyphicon glyphicon-plus"></span> Disciplina
                                        </a>
                                    </div>  
                                </div>
                                <table class="table table-striped bunitu">
                                    <thead class="btn-primary">
                                        <tr class="row text-uppercase">
                                            <th class="text-center" style="vertical-align: middle;">Nome</th>
                                            <th class="text-center" style="vertical-align: middle;">Sigla</th>
                                            <th class="text-center" style="vertical-align: middle;">Cursos</th>
                                            <th class="text-center" style="vertical-align: middle;">Ação</th>
                                        </tr>
                                    </thead>
                                    @foreach($disciplinas as $disciplina)
                                        
                                        <tr class="row text-uppercase">
                                            <td class="text-center" style="vertical-align: middle;"> {{ $disciplina->nome }} </td>
                                            <td class="text-center" style="vertical-align: middle;"> {{ $disciplina->sigla }} </td>
                                            <td class="text-center" style="vertical-align: middle;">

                                                @foreach($disciplina->cursos->unique() as $curso)
                                                    {{$curso->nome}} <br>
                                                @endforeach
                                            </td>
                                            <td class="text-center" style="vertical-align: middle;">
                                                <div class="btn-group-xs btn-group-vertical btn-block">
                                                    <a class='btn btn-info' href="{{route('disciplina.edit',$disciplina->id)}}">
                                                        <span class="glyphicon glyphicon-edit"></span> Editar
                                                    </a>
                                                    <a class="btn"></a>
                                                    
                                                    <a type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal" data-entidade="disciplina" data-url="{{route('disciplina.delete',$disciplina->id)}}">
                                                        <span class="glyphicon glyphicon-remove" ></span> Excluir
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </table>

                                {{ $disciplinas->appends(['pesquisa' => $pesquisa])->links() }}
                            </div>
                            @endif
                        </div>

                    </div>
                </div>
            </div>
        </div>
    @include('layout.modal')
@endsection