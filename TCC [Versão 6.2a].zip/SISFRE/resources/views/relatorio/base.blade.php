<!DOCTYPE html>
<html lang="pt-br">
	<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> @yield('titulo') </title>
        <link href="{{public_path()}}/img/favicon.png" rel="shortcut icon" />
        <link href="{{public_path()}}/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="{{public_path()}}/css/print.css" rel="stylesheet" type="text/css">
        <link href="{{public_path()}}/css/estilo.css" rel="stylesheet" type="text/css">

	</head>
	<body>

        <div class="container">
            <header class="row">
                <nav class="navbar nav-justified center well-sm">
                    <div class="container-fluid col-md-4 col-xs-offset-4" >
                       <a><img src="{{public_path()}}/img/sisfre.png" class="img-responsive"></a>
                    </div>
                </nav>
                <div class="container-fluid col-md-5 col-xs-offset-4 text-uppercase" style="vertical-align: center;padding-bottom: 1.0em">
                    <p>
                         <b> Curso: </b> {{Auth::user()->professor->curso->nome}}<br>
                         <b>Coordenador: </b> {{Auth::user()->professor->usuario->username}}<br>
                         <b>Semestre: </b> @yield('semestre')
                    </p>

                </div>
            </header>

            <div class="row">
                @yield('conteudo')
            </div>
            
        </div>

	</body>
</html>